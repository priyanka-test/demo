import '@angular/core';
import '@angular/common';
import '@angular/compiler';
import '@angular/forms';
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';
import '@angular/router';
import 'angular-font-awesome';
// import '@angular/material';
// import '@angular/animation';
// import '@angular/cdk';

import 'rxjs';
import 'tslib';

import 'jquery';
import 'bootstrap';
import 'popper.js';
import 'ag-grid-angular';
import '@swimlane/ngx-datatable';
// import 'bootstrap/dist/css/bootstrap.css';
// import 'bootstrap/dist/css/bootstrap-theme.css'; // for bootstrap 3
import 'bootstrap/scss/bootstrap.scss'; // for bootstrap 4
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import 'font-awesome/css/font-awesome.css';
import 'font-awesome/css/font-awesome.min.css';
import '@swimlane/ngx-datatable/assets/icons.css'
//import '@ag-grid-community/all-modules/dist/styles/ag-grid.css';
//import '@ag-grid-community/all-modules/dist/styles/ag-theme-balham.css';