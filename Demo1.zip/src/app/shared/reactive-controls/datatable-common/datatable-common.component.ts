import { Component, OnInit, ViewChild, Input } from "@angular/core";


@Component({
    selector:'pioneer-datatable',
    templateUrl:'datatable-common.component.html',
    styleUrls:['./datatable-common.component.css']
})
export class DatatableCommonComponent implements OnInit{
    @ViewChild('myTable') table: any;

    @Input() data:any[];
    @Input() columns:any[];
    @Input() checkboxSelection:boolean = false;
    @Input() parentExpandable:boolean = false;
    expanded: any = {};
    timeout: any;
    selected = [];

    constructor(){}

    ngOnInit(){
        
    }

    
      toggleExpandRow(row) {
        //console.log('Toggled Expand Row!', row);
        this.table.rowDetail.toggleExpandRow(row);
      }
    
      onDetailToggle(event) {
        //console.log('Detail Toggled', event);
      }

      onSelect({ selected }) {
    
        this.selected.splice(0, this.selected.length);
        this.selected.push(...selected);
      }
} 