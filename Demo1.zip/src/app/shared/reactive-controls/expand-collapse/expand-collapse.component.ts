import { Component, Input } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'expand-collapse',
    templateUrl: 'expand-collapse.component.html',
    styles: [
        `.btn {
            line-height: 0.1
        }`
    ]
})
export class Expandcollapsecomponent implements ICellRendererAngularComp{
public expanded:boolean = false;
params:any;
    constructor(){}

    // called on init
    agInit(params: any): void {
        //console.log(params);
        this.params=params;
    }

    // called when the cell is refreshed
    refresh(params: any): boolean {
        return false;
    }

    onExpand(){
        this.expanded = !this.expanded;
        console.log(this.params);
        this.params.context.componentParent.onExpand(this.params.node);
    }
    onCollapse(){
        this.expanded = !this.expanded;
        this.params.context.componentParent.oncollapse(this.params.node);
    }


}