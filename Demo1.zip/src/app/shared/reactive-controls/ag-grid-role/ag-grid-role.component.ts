import { Component, Input, OnInit } from "@angular/core";
import { AllocationDetailcomponent } from "../../../allocation/allocationdetail.component";
import { GridApi, ColumnApi, Context, GridOptions } from "ag-grid-community";
import { Expandcollapsecomponent } from "../expand-collapse/expand-collapse.component";

@Component({
    selector:'ag-grid-role',
    templateUrl:'ag-grid-role.component.html',
    styleUrls:['./ag-grid-role.component.css']
})
export class AgGridRoleComponent implements OnInit{

    @Input() checkboxselection?:boolean = false;
    @Input() parentExpandable?:boolean = false;
    @Input() columnDef: any[]=[];
    @Input() multipleRowSelection:boolean= true;
    @Input() data:any[];
    frameworkComponents: any;

    //isExpandedCellFullWidth:boolean = true;
    fullWidthcellRenderer:string;
    gridApi:GridApi;
    gridColumnApi:ColumnApi;
    agColumnDef:any[]=[];
    getRowHeight:any;
    rowSelection:string;
    private context:any;
    gridOption:GridOptions;
    rowClassRule:any;
    rowcls:any;

    constructor(){

    }

    ngOnInit(){

        
        //customElements.define('full-width-cell-renderer',AllocationDetailcomponent);
        this.getRowHeight = (params) =>{
            return this.isFullWidth(params) ? 200 : 25;
          };
        this.defineColumns();
        this.rowSelection = this.multipleRowSelection? "multiple" : "single";
        this.context = { componentParent: this };
        //this.gridOption.rowClass="ag-grid-row-style";
        this.rowcls='pioneer-grid';
        // this.rowClassRule={
        //     "pioneer-grid":function (params){
        //         var name = params.data.empname;
        //     return name=="pri";
        // }};
        // this.gridOption.rowStyle={
        //     background:'#e5f2f2',
        //     border:'1px 1px 1px 3px #00847f'
        // };
       // this.gridOption.
        if(this.parentExpandable){
            this.fullWidthcellRenderer = "fullwidthcellrenderer";
            this.frameworkComponents = { fullwidthcellrenderer: AllocationDetailcomponent,
                expandCollpaseiconRenderer: Expandcollapsecomponent };
        }
        
    }

    isFullWidth(param){
        return param.data.isExpandedCellFullWidth == "true";
    }

    onGridReady(params) {
        params.api.sizeColumnsToFit();
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;  
      }

    onExpand(data){
        this.addNewRow(data.rowIndex);
     }

     oncollapse(data){   
        var rowNode = this.gridApi.getDisplayedRowAtIndex(data.rowIndex+1);
       this.gridApi.updateRowData({
        remove: [rowNode.data]
         });
     }

     addNewRow(rowindex:number){
        
        var newItem = this.createNewRowData();
        this.gridApi.updateRowData({
            add: [newItem],
            addIndex: rowindex+1
          });
      }

      createNewRowData() {
        var newData = {
            isExpandedCellFullWidth:"true"
        };
        return newData;
      }

      getPreviousRowData(data){
        var rowNode = this.gridApi.getDisplayedRowAtIndex(data.rowIndex-1);
        return rowNode.data;
      }

      defineColumns(){
          if(this.parentExpandable){
            this.agColumnDef.push({
                headerName:"",
                width: 30,
                cellRendererFramework:Expandcollapsecomponent
              }); 
          }
          if(this.checkboxselection){
            this.agColumnDef.push({
                headerName:"",
                width: 30,
                checkboxSelection:true
              });
          }

          this.columnDef.map(c =>{
            this.agColumnDef.push({headerName: c.columnHeader,
                field:c.columnName,
                hide:!c.isChecked,
                width: c.width,
                headerTooltip: c.columnHeader,
                resizable:true}) ;
          });   
      }
}