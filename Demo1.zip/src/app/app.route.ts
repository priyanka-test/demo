import { Routes } from "@angular/router";
import { HeadCountgridComponent } from "./headcount/headcountgrid.component";
import { ChangeRequestComponent } from "./changerequest/changerequest.component";


export const route:Routes=[
    {path:'',component:HeadCountgridComponent},
    {path:'changerequest',component:ChangeRequestComponent}
];