import { Component, OnInit } from "@angular/core";


@Component({
    selector:'nav-tab',
    templateUrl:'navigation-tab.component.html',
    styleUrls:['./navigation-tab.component.scss']
})
export class NavigationTabComponent implements OnInit{

    constructor(){}

    ngOnInit(){}
}