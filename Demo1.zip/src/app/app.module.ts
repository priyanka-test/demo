import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import {HttpClientModule} from '@angular/common/http'
import { AppComponent } from "./app.component";
import {AgGridModule} from "ag-grid-angular";


import {HeadCountgridComponent} from './headcount/headcountgrid.component'
import { AllocationDetailcomponent } from "./allocation/allocationdetail.component";
import { Expandcollapsecomponent } from "./shared/reactive-controls/expand-collapse/expand-collapse.component";
import { AngularFontAwesomeModule } from "angular-font-awesome";
import {route} from './app.route';
import { RouterModule } from "@angular/router";
import { NavigationTabComponent } from "./navigation-tab/navigation-tab.component";
import { ChangeRequestComponent } from "./changerequest/changerequest.component";
import { APP_BASE_HREF } from "@angular/common";
import { AgGridRoleComponent } from "./shared/reactive-controls/ag-grid-role/ag-grid-role.component";
import { HomeComponent } from "./home/home.component";
import { AllocationDetail2component } from "./allocation2/allocationdetail2.component";
import { DatatableCommonComponent } from "./shared/reactive-controls/datatable-common/datatable-common.component";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
//import { MatIconModule, MatButtonModule } from "@angular/material";

@NgModule({
    imports: [BrowserModule,
                AgGridModule.withComponents([AllocationDetailcomponent,Expandcollapsecomponent]),
            HttpClientModule, AngularFontAwesomeModule,
            NgxDatatableModule,
        RouterModule.forRoot(route)],
    declarations: [AppComponent
                    ,HeadCountgridComponent
                    ,AllocationDetailcomponent
                    ,Expandcollapsecomponent
                    ,NavigationTabComponent
                    ,ChangeRequestComponent,
                    AgGridRoleComponent,
                    AllocationDetail2component,
                    DatatableCommonComponent
                    //HomeComponent
        ],
    bootstrap: [AppComponent],
    providers: [
        {
            provide: APP_BASE_HREF,
            useValue:'/'
        },
        {
        provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
            return (component: ComponentRef<any>) => {
                console.log(component);
            }
        }
    }]
})
export class AppModule {

}