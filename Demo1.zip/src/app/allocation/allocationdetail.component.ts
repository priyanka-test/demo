import { Component, Input } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'allocation-detail',
    templateUrl: 'allocationdetail.component.html'
})
export class AllocationDetailcomponent implements ICellRendererAngularComp{
    param:any;
    ctoolId:string="";
    data:any;

    constructor(){}

    // called on init
    agInit(params: any): void {
        this.param = params;
        //console.log(this.param);
        this.data=this.param.context.componentParent.getPreviousRowData(this.param.node);
        this.ctoolId = this.data.ctoolid;
    }

    // called when the cell is refreshed
    refresh(params: any): boolean {
        return false;
    }
}