import { Component } from "@angular/core";

@Component({
    selector:'change-request',
    templateUrl:'changerequest.component.html'
})
export class ChangeRequestComponent{
    constructor(){}

}