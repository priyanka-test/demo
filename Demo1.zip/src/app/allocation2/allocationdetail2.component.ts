import { Component, Input, OnInit } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'allocation-detail2',
    templateUrl: 'allocationdetail2.component.html'
})
export class AllocationDetail2component implements OnInit{
   
    @Input() ctoolId:string="";

    constructor(){}

    ngOnInit(){

    }
}