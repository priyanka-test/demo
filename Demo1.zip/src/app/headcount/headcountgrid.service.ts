import {HeadCountColumn} from './headcountcolumn';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class HeadCountGridService{
    private url: string;
    private headcountgridColumnList:HeadCountColumn[];
    constructor( private httpClient:HttpClient){
        this.url="https://my-json-server.typicode.com/priyanka-test/demo/headcountdata";
        this.headcountgridColumnList = [
            {
                title: 'cTool ID',
                name: 'ctoolid',
                width:'80',
                type:'number'
            },
            {
                title: 'Employee ID',
                name: 'employeeid',
                width:'80',
                type:'number'
            },
            {
                title: 'Full Name',
                name: 'empname',
                width:'100',
                type:'text'
            },
            {
                title: 'Direct Cost',
                name: 'directcost',
                width:'80',
                type:'number'
            },
            {
                title: 'Role Start date',
                name: 'rolestartdate',
                width:'80',
                type:'date'
            },
            {
                title: 'Role End date',
                name: 'roleenddate',
                width:'80',
                type:'date'
            },
            {
                title: 'Location',
                name: 'location',
                width:'100',
                type:'text'
            }
        //     {
        //     columnHeader: 'cTool ID',
        //     columnName: 'ctoolid',
        //     isChecked: true,
        //     width:'80',
        //     type:'number'
        // },
        // {
        //     columnHeader: 'Employee ID',
        //     columnName: 'employeeid',
        //     isChecked: false,
        //     width:'80',
        //     type:'number'
        // },
        // {
        //     columnHeader: 'Full Name',
        //     columnName: 'empname',
        //     isChecked: true,
        //     width:'100',
        //     type:'text'
        // },
        // {
        //     columnHeader: 'Direct Cost',
        //     columnName: 'directcost',
        //     isChecked: true,
        //     width:'80',
        //     type:'number'
        // },
        // {
        //     columnHeader: 'Role Start date',
        //     columnName: 'rolestartdate',
        //     isChecked: true,
        //     width:'80',
        //     type:'date'
        // },
        // {
        //     columnHeader: 'Role End date',
        //     columnName: 'roleenddate',
        //     isChecked: true,
        //     width:'80',
        //     type:'date'
        // },
        // {
        //     columnHeader: 'Location',
        //     columnName: 'location',
        //     isChecked: true,
        //     width:'100',
        //     type:'text'
        // }
        
    ];
    }

    getData(){
        return this.httpClient.get<Array<any>>(this.url);
    }

    getColumns(){
        return this.headcountgridColumnList;
    }
}