export class HeadCountColumn{
    // columnHeader:string;
    // columnName:string;
    // isChecked:boolean;
    // width?:string;
    // type?:string;

    title:string;
    name:string;
    width?:string;
    type?:string;
}