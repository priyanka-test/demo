import {Component,OnInit} from '@angular/core';
import { HeadCountGridService } from './headcountgrid.service';

@Component({
    selector: 'headcount-grid',
    templateUrl: 'headcountgrid.component.html',
    styleUrls:['./headcount.component.scss'],
    providers:[HeadCountGridService]
})
export class HeadCountgridComponent implements OnInit{
    columndefs:any[]=[];
    rowdata:any[]=[];
  
    constructor(private headcountgridService:HeadCountGridService){

    }

    ngOnInit(){
      this.columndefs=this.headcountgridService.getColumns();  
      this.headcountgridService.getData().subscribe(data => {
          this.rowdata=data;
          
      });

    }

}